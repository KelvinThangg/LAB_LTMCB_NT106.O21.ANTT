﻿namespace LAB2
{
    partial class BFormatter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.idTxt = new Guna.UI2.WinForms.Guna2TextBox();
            this.nameTxt = new Guna.UI2.WinForms.Guna2TextBox();
            this.phoneTxt = new Guna.UI2.WinForms.Guna2TextBox();
            this.mathTxt = new Guna.UI2.WinForms.Guna2TextBox();
            this.litrTxt = new Guna.UI2.WinForms.Guna2TextBox();
            this.showTxt = new Guna.UI2.WinForms.Guna2TextBox();
            this.writeBtn = new Guna.UI2.WinForms.Guna2Button();
            this.readBtn = new Guna.UI2.WinForms.Guna2Button();
            this.clearTxt = new Guna.UI2.WinForms.Guna2Button();
            this.exitBtn = new Guna.UI2.WinForms.Guna2Button();
            this.delBtn = new Guna.UI2.WinForms.Guna2Button();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // guna2BorderlessForm1
            // 
            this.guna2BorderlessForm1.BorderRadius = 30;
            this.guna2BorderlessForm1.ContainerControl = this;
            this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            this.guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Shopee Display ExtBd", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(19, 128);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 27);
            this.label1.TabIndex = 41;
            this.label1.Text = "MSSV:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Shopee Display ExtBd", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.Location = new System.Drawing.Point(19, 198);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 27);
            this.label2.TabIndex = 42;
            this.label2.Text = "HoTen:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Shopee Display ExtBd", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.Location = new System.Drawing.Point(19, 261);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 27);
            this.label3.TabIndex = 43;
            this.label3.Text = "DienThoai:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Shopee Display ExtBd", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(19, 332);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 27);
            this.label4.TabIndex = 44;
            this.label4.Text = "DiemToan:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Shopee Display ExtBd", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.Location = new System.Drawing.Point(19, 402);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 27);
            this.label5.TabIndex = 45;
            this.label5.Text = "DiemVan:";
            // 
            // idTxt
            // 
            this.idTxt.BorderRadius = 13;
            this.idTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.idTxt.DefaultText = "";
            this.idTxt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.idTxt.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.idTxt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.idTxt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.idTxt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.idTxt.Font = new System.Drawing.Font("Mulish Light", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.idTxt.ForeColor = System.Drawing.Color.Black;
            this.idTxt.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.idTxt.Location = new System.Drawing.Point(126, 128);
            this.idTxt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.idTxt.Name = "idTxt";
            this.idTxt.PasswordChar = '\0';
            this.idTxt.PlaceholderText = "";
            this.idTxt.SelectedText = "";
            this.idTxt.Size = new System.Drawing.Size(246, 27);
            this.idTxt.TabIndex = 47;
            // 
            // nameTxt
            // 
            this.nameTxt.BorderRadius = 13;
            this.nameTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.nameTxt.DefaultText = "";
            this.nameTxt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.nameTxt.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.nameTxt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.nameTxt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.nameTxt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.nameTxt.Font = new System.Drawing.Font("Mulish Light", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.nameTxt.ForeColor = System.Drawing.Color.Black;
            this.nameTxt.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.nameTxt.Location = new System.Drawing.Point(126, 197);
            this.nameTxt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.nameTxt.Name = "nameTxt";
            this.nameTxt.PasswordChar = '\0';
            this.nameTxt.PlaceholderText = "";
            this.nameTxt.SelectedText = "";
            this.nameTxt.Size = new System.Drawing.Size(246, 28);
            this.nameTxt.TabIndex = 48;
            // 
            // phoneTxt
            // 
            this.phoneTxt.BorderRadius = 13;
            this.phoneTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.phoneTxt.DefaultText = "";
            this.phoneTxt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.phoneTxt.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.phoneTxt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.phoneTxt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.phoneTxt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.phoneTxt.Font = new System.Drawing.Font("Mulish Light", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.phoneTxt.ForeColor = System.Drawing.Color.Black;
            this.phoneTxt.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.phoneTxt.Location = new System.Drawing.Point(126, 260);
            this.phoneTxt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.phoneTxt.Name = "phoneTxt";
            this.phoneTxt.PasswordChar = '\0';
            this.phoneTxt.PlaceholderText = "";
            this.phoneTxt.SelectedText = "";
            this.phoneTxt.Size = new System.Drawing.Size(246, 28);
            this.phoneTxt.TabIndex = 49;
            this.phoneTxt.TextChanged += new System.EventHandler(this.phoneTxt_TextChanged);
            // 
            // mathTxt
            // 
            this.mathTxt.BorderRadius = 13;
            this.mathTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.mathTxt.DefaultText = "";
            this.mathTxt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.mathTxt.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.mathTxt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.mathTxt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.mathTxt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.mathTxt.Font = new System.Drawing.Font("Mulish Light", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.mathTxt.ForeColor = System.Drawing.Color.Black;
            this.mathTxt.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.mathTxt.Location = new System.Drawing.Point(126, 331);
            this.mathTxt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.mathTxt.Name = "mathTxt";
            this.mathTxt.PasswordChar = '\0';
            this.mathTxt.PlaceholderText = "";
            this.mathTxt.SelectedText = "";
            this.mathTxt.Size = new System.Drawing.Size(246, 28);
            this.mathTxt.TabIndex = 50;
            // 
            // litrTxt
            // 
            this.litrTxt.BorderRadius = 13;
            this.litrTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.litrTxt.DefaultText = "";
            this.litrTxt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.litrTxt.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.litrTxt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.litrTxt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.litrTxt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.litrTxt.Font = new System.Drawing.Font("Mulish Light", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.litrTxt.ForeColor = System.Drawing.Color.Black;
            this.litrTxt.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.litrTxt.Location = new System.Drawing.Point(126, 401);
            this.litrTxt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.litrTxt.Name = "litrTxt";
            this.litrTxt.PasswordChar = '\0';
            this.litrTxt.PlaceholderText = "";
            this.litrTxt.SelectedText = "";
            this.litrTxt.Size = new System.Drawing.Size(246, 28);
            this.litrTxt.TabIndex = 51;
            // 
            // showTxt
            // 
            this.showTxt.BorderRadius = 20;
            this.showTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.showTxt.DefaultText = "";
            this.showTxt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.showTxt.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.showTxt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.showTxt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.showTxt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.showTxt.Font = new System.Drawing.Font("Mulish Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.showTxt.ForeColor = System.Drawing.Color.Black;
            this.showTxt.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.showTxt.Location = new System.Drawing.Point(415, 55);
            this.showTxt.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.showTxt.Multiline = true;
            this.showTxt.Name = "showTxt";
            this.showTxt.PasswordChar = '\0';
            this.showTxt.PlaceholderText = "";
            this.showTxt.ReadOnly = true;
            this.showTxt.SelectedText = "";
            this.showTxt.Size = new System.Drawing.Size(445, 521);
            this.showTxt.TabIndex = 53;
            // 
            // writeBtn
            // 
            this.writeBtn.BorderRadius = 23;
            this.writeBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.writeBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.writeBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.writeBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.writeBtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(17)))), ((int)(((byte)(27)))));
            this.writeBtn.Font = new System.Drawing.Font("Shopee Display Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.writeBtn.ForeColor = System.Drawing.Color.White;
            this.writeBtn.Location = new System.Drawing.Point(64, 465);
            this.writeBtn.Name = "writeBtn";
            this.writeBtn.Size = new System.Drawing.Size(140, 45);
            this.writeBtn.TabIndex = 54;
            this.writeBtn.Text = "Ghi File";
            this.writeBtn.Click += new System.EventHandler(this.writeBtn_Click);
            // 
            // readBtn
            // 
            this.readBtn.BorderRadius = 23;
            this.readBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.readBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.readBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.readBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.readBtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(115)))), ((int)(((byte)(126)))));
            this.readBtn.Font = new System.Drawing.Font("Shopee Display Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.readBtn.ForeColor = System.Drawing.Color.White;
            this.readBtn.Location = new System.Drawing.Point(221, 465);
            this.readBtn.Name = "readBtn";
            this.readBtn.Size = new System.Drawing.Size(140, 45);
            this.readBtn.TabIndex = 55;
            this.readBtn.Text = "Đọc File";
            this.readBtn.Click += new System.EventHandler(this.readBtn_Click);
            // 
            // clearTxt
            // 
            this.clearTxt.BorderRadius = 23;
            this.clearTxt.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.clearTxt.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.clearTxt.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.clearTxt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.clearTxt.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(153)))), ((int)(((byte)(90)))));
            this.clearTxt.Font = new System.Drawing.Font("Shopee Display Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.clearTxt.ForeColor = System.Drawing.Color.White;
            this.clearTxt.Location = new System.Drawing.Point(64, 529);
            this.clearTxt.Name = "clearTxt";
            this.clearTxt.Size = new System.Drawing.Size(140, 45);
            this.clearTxt.TabIndex = 56;
            this.clearTxt.Text = "Xóa nhập";
            this.clearTxt.Click += new System.EventHandler(this.clearTxt_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.BorderRadius = 19;
            this.exitBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.exitBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.exitBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.exitBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.exitBtn.FillColor = System.Drawing.Color.Maroon;
            this.exitBtn.Font = new System.Drawing.Font("Shopee Display Black", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.exitBtn.ForeColor = System.Drawing.Color.White;
            this.exitBtn.Location = new System.Drawing.Point(804, -5);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(104, 41);
            this.exitBtn.TabIndex = 57;
            this.exitBtn.Text = "      X";
            this.exitBtn.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // delBtn
            // 
            this.delBtn.BorderRadius = 23;
            this.delBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.delBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.delBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.delBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.delBtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(78)))), ((int)(((byte)(27)))));
            this.delBtn.Font = new System.Drawing.Font("Shopee Display Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.delBtn.ForeColor = System.Drawing.Color.White;
            this.delBtn.Location = new System.Drawing.Point(221, 529);
            this.delBtn.Name = "delBtn";
            this.delBtn.Size = new System.Drawing.Size(140, 45);
            this.delBtn.TabIndex = 58;
            this.delBtn.Text = "Xóa File";
            this.delBtn.Click += new System.EventHandler(this.delBtn_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Shopee Display Black", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(46)))), ((int)(((byte)(50)))));
            this.label6.Location = new System.Drawing.Point(14, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(357, 52);
            this.label6.TabIndex = 59;
            this.label6.Text = "BINARY FORMATTER";
            // 
            // BFormatter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(885, 613);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.delBtn);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.clearTxt);
            this.Controls.Add(this.readBtn);
            this.Controls.Add(this.writeBtn);
            this.Controls.Add(this.showTxt);
            this.Controls.Add(this.litrTxt);
            this.Controls.Add(this.mathTxt);
            this.Controls.Add(this.phoneTxt);
            this.Controls.Add(this.nameTxt);
            this.Controls.Add(this.idTxt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BFormatter";
            this.Text = "BFormatter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private Guna.UI2.WinForms.Guna2TextBox idTxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox showTxt;
        private Guna.UI2.WinForms.Guna2TextBox litrTxt;
        private Guna.UI2.WinForms.Guna2TextBox mathTxt;
        private Guna.UI2.WinForms.Guna2TextBox phoneTxt;
        private Guna.UI2.WinForms.Guna2TextBox nameTxt;
        private Guna.UI2.WinForms.Guna2Button writeBtn;
        private Guna.UI2.WinForms.Guna2Button readBtn;
        private Guna.UI2.WinForms.Guna2Button clearTxt;
        private Guna.UI2.WinForms.Guna2Button exitBtn;
        private Guna.UI2.WinForms.Guna2Button delBtn;
        private System.Windows.Forms.Label label6;
    }
}