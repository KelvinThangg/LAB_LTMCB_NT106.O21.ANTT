﻿namespace LAB2
{
    partial class FormMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.bai1Btn = new Guna.UI2.WinForms.Guna2Button();
            this.bai2Btn = new Guna.UI2.WinForms.Guna2Button();
            this.bai3Btn = new Guna.UI2.WinForms.Guna2Button();
            this.bai4Btn = new Guna.UI2.WinForms.Guna2Button();
            this.bai5Btn = new Guna.UI2.WinForms.Guna2Button();
            this.exitBtn = new Guna.UI2.WinForms.Guna2Button();
            this.guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.SuspendLayout();
            // 
            // button7
            // 
            this.button7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(61)))), ((int)(((byte)(85)))));
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("SVN-Gotham Ultra", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(-3, -1);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(806, 83);
            this.button7.TabIndex = 14;
            this.button7.Text = "LAB2 MENU - NHÓM 4";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(61)))), ((int)(((byte)(85)))));
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Shopee Display", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(-3, 331);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(806, 122);
            this.button6.TabIndex = 13;
            this.button6.Text = "Lập trình mạng căn bản - NT106.O21.ANTT.2\r\nGVTH: Tô Trọng Nghĩa\r\n22521630 - Lê Th" +
    "ị Bích Tuyền\r\n22521709 - Trần Thị Thúy Vy";
            this.button6.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button6.UseVisualStyleBackColor = false;
            // 
            // bai1Btn
            // 
            this.bai1Btn.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(25)))), ((int)(((byte)(37)))));
            this.bai1Btn.BorderRadius = 24;
            this.bai1Btn.BorderThickness = 2;
            this.bai1Btn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.bai1Btn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.bai1Btn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.bai1Btn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.bai1Btn.FillColor = System.Drawing.Color.White;
            this.bai1Btn.Font = new System.Drawing.Font("Shopee Display ExtBd", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bai1Btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            this.bai1Btn.Location = new System.Drawing.Point(132, 133);
            this.bai1Btn.Name = "bai1Btn";
            this.bai1Btn.Size = new System.Drawing.Size(156, 51);
            this.bai1Btn.TabIndex = 16;
            this.bai1Btn.Text = "Bài 1";
            this.bai1Btn.Click += new System.EventHandler(this.bai1Btn_Click);
            // 
            // bai2Btn
            // 
            this.bai2Btn.BorderRadius = 24;
            this.bai2Btn.BorderThickness = 2;
            this.bai2Btn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.bai2Btn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.bai2Btn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.bai2Btn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.bai2Btn.FillColor = System.Drawing.Color.White;
            this.bai2Btn.Font = new System.Drawing.Font("Shopee Display ExtBd", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bai2Btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            this.bai2Btn.Location = new System.Drawing.Point(306, 133);
            this.bai2Btn.Name = "bai2Btn";
            this.bai2Btn.Size = new System.Drawing.Size(156, 51);
            this.bai2Btn.TabIndex = 17;
            this.bai2Btn.Text = "Bài 2";
            this.bai2Btn.Click += new System.EventHandler(this.bai2Btn_Click);
            // 
            // bai3Btn
            // 
            this.bai3Btn.BorderRadius = 24;
            this.bai3Btn.BorderThickness = 2;
            this.bai3Btn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.bai3Btn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.bai3Btn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.bai3Btn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.bai3Btn.FillColor = System.Drawing.Color.White;
            this.bai3Btn.Font = new System.Drawing.Font("Shopee Display ExtBd", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bai3Btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            this.bai3Btn.Location = new System.Drawing.Point(474, 134);
            this.bai3Btn.Name = "bai3Btn";
            this.bai3Btn.Size = new System.Drawing.Size(156, 50);
            this.bai3Btn.TabIndex = 18;
            this.bai3Btn.Text = "Bài 3";
            this.bai3Btn.Click += new System.EventHandler(this.bai3Btn_Click);
            // 
            // bai4Btn
            // 
            this.bai4Btn.BorderRadius = 23;
            this.bai4Btn.BorderThickness = 2;
            this.bai4Btn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.bai4Btn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.bai4Btn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.bai4Btn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.bai4Btn.FillColor = System.Drawing.Color.White;
            this.bai4Btn.Font = new System.Drawing.Font("Shopee Display ExtBd", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bai4Btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            this.bai4Btn.Location = new System.Drawing.Point(132, 215);
            this.bai4Btn.Name = "bai4Btn";
            this.bai4Btn.Size = new System.Drawing.Size(155, 49);
            this.bai4Btn.TabIndex = 19;
            this.bai4Btn.Text = "Bài 4";
            this.bai4Btn.Click += new System.EventHandler(this.bai4Btn_Click);
            // 
            // bai5Btn
            // 
            this.bai5Btn.BorderRadius = 24;
            this.bai5Btn.BorderThickness = 2;
            this.bai5Btn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.bai5Btn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.bai5Btn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.bai5Btn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.bai5Btn.FillColor = System.Drawing.Color.White;
            this.bai5Btn.Font = new System.Drawing.Font("Shopee Display ExtBd", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bai5Btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            this.bai5Btn.Location = new System.Drawing.Point(306, 213);
            this.bai5Btn.Name = "bai5Btn";
            this.bai5Btn.Size = new System.Drawing.Size(155, 50);
            this.bai5Btn.TabIndex = 20;
            this.bai5Btn.Text = "Bài 5";
            this.bai5Btn.Click += new System.EventHandler(this.bai5Btn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.BorderRadius = 24;
            this.exitBtn.BorderThickness = 1;
            this.exitBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.exitBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.exitBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.exitBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.exitBtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(25)))), ((int)(((byte)(37)))));
            this.exitBtn.Font = new System.Drawing.Font("Shopee Display ExtBd", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.exitBtn.ForeColor = System.Drawing.Color.White;
            this.exitBtn.Location = new System.Drawing.Point(475, 213);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(155, 51);
            this.exitBtn.TabIndex = 21;
            this.exitBtn.Text = "Thoát";
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // guna2BorderlessForm1
            // 
            this.guna2BorderlessForm1.BorderRadius = 30;
            this.guna2BorderlessForm1.ContainerControl = this;
            this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            this.guna2BorderlessForm1.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(25)))), ((int)(((byte)(37)))));
            this.guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // FormMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.bai5Btn);
            this.Controls.Add(this.bai4Btn);
            this.Controls.Add(this.bai3Btn);
            this.Controls.Add(this.bai2Btn);
            this.Controls.Add(this.bai1Btn);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormMenu";
            this.Text = "FormMenu";
            this.Load += new System.EventHandler(this.FormMenu_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private Guna.UI2.WinForms.Guna2Button bai1Btn;
        private Guna.UI2.WinForms.Guna2Button bai2Btn;
        private Guna.UI2.WinForms.Guna2Button bai3Btn;
        private Guna.UI2.WinForms.Guna2Button bai4Btn;
        private Guna.UI2.WinForms.Guna2Button bai5Btn;
        private Guna.UI2.WinForms.Guna2Button exitBtn;
        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
    }
}