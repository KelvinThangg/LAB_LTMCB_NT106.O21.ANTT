﻿namespace ThucHanhMang_Lab2
{
    partial class lab2_Bai2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.soKyTu = new System.Windows.Forms.TextBox();
            this.soTu = new System.Windows.Forms.TextBox();
            this.soDong = new System.Windows.Forms.TextBox();
            this.duongDan = new System.Windows.Forms.TextBox();
            this.tenFile = new System.Windows.Forms.TextBox();
            this.richTextBoxShow = new System.Windows.Forms.RichTextBox();
            this.btnRead = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(86, 363);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 16);
            this.label5.TabIndex = 23;
            this.label5.Text = "Số ký tự";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(86, 314);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 16);
            this.label4.TabIndex = 22;
            this.label4.Text = "Số từ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(86, 269);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 16);
            this.label3.TabIndex = 21;
            this.label3.Text = "Số dòng";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(86, 215);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 16);
            this.label2.TabIndex = 20;
            this.label2.Text = "URL";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(86, 159);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 16);
            this.label1.TabIndex = 19;
            this.label1.Text = "Tên File";
            // 
            // soKyTu
            // 
            this.soKyTu.Location = new System.Drawing.Point(189, 350);
            this.soKyTu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.soKyTu.Multiline = true;
            this.soKyTu.Name = "soKyTu";
            this.soKyTu.Size = new System.Drawing.Size(198, 30);
            this.soKyTu.TabIndex = 18;
            // 
            // soTu
            // 
            this.soTu.Location = new System.Drawing.Point(189, 300);
            this.soTu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.soTu.Multiline = true;
            this.soTu.Name = "soTu";
            this.soTu.Size = new System.Drawing.Size(198, 30);
            this.soTu.TabIndex = 17;
            // 
            // soDong
            // 
            this.soDong.Location = new System.Drawing.Point(189, 255);
            this.soDong.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.soDong.Multiline = true;
            this.soDong.Name = "soDong";
            this.soDong.Size = new System.Drawing.Size(198, 30);
            this.soDong.TabIndex = 16;
            // 
            // duongDan
            // 
            this.duongDan.Location = new System.Drawing.Point(189, 202);
            this.duongDan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.duongDan.Multiline = true;
            this.duongDan.Name = "duongDan";
            this.duongDan.Size = new System.Drawing.Size(198, 40);
            this.duongDan.TabIndex = 15;
            // 
            // tenFile
            // 
            this.tenFile.Location = new System.Drawing.Point(189, 157);
            this.tenFile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tenFile.Multiline = true;
            this.tenFile.Name = "tenFile";
            this.tenFile.Size = new System.Drawing.Size(198, 30);
            this.tenFile.TabIndex = 14;
            // 
            // richTextBoxShow
            // 
            this.richTextBoxShow.Location = new System.Drawing.Point(453, 114);
            this.richTextBoxShow.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.richTextBoxShow.Name = "richTextBoxShow";
            this.richTextBoxShow.Size = new System.Drawing.Size(262, 266);
            this.richTextBoxShow.TabIndex = 13;
            this.richTextBoxShow.Text = "";
            // 
            // btnRead
            // 
            this.btnRead.Location = new System.Drawing.Point(189, 97);
            this.btnRead.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(198, 35);
            this.btnRead.TabIndex = 12;
            this.btnRead.Text = "Đọc File";
            this.btnRead.UseVisualStyleBackColor = true;
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(189, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(198, 39);
            this.button1.TabIndex = 24;
            this.button1.Text = "Thoát";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lab2_Bai2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ThucHanhMang_Lab2.Properties.Resources.hinh_nen_dang_yeu_cute_cho_may_tinh_115833037;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.soKyTu);
            this.Controls.Add(this.soTu);
            this.Controls.Add(this.soDong);
            this.Controls.Add(this.duongDan);
            this.Controls.Add(this.tenFile);
            this.Controls.Add(this.richTextBoxShow);
            this.Controls.Add(this.btnRead);
            this.Name = "lab2_Bai2";
            this.Text = "lab2_Bai2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox soKyTu;
        private System.Windows.Forms.TextBox soTu;
        private System.Windows.Forms.TextBox soDong;
        private System.Windows.Forms.TextBox duongDan;
        private System.Windows.Forms.TextBox tenFile;
        private System.Windows.Forms.RichTextBox richTextBoxShow;
        private System.Windows.Forms.Button btnRead;
        private System.Windows.Forms.Button button1;
    }
}